#!/usr/bin/env python
from brain_games import logic_brain_even


def main():
    logic_brain_even.start_brain_even()


if __name__ == '__main__':
    main()
